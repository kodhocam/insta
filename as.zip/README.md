# instaCreate
Instagram Account Creator.

## How to use with proxy?
Create "proxylist.txt"

## Why not working?
You need edit csrf and mid token in class.php
